﻿Public Class KhachHang

    'Private Sub KhachHang_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    '    FillGrid()
    'End Sub

    'Private Sub FillGrid()
    '    Dim db As New DataClasses1DataContext
    '    GridControl1.DataSource = db.KhachHangs.ToList()
    'End Sub

    'Private Sub btnThem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThem.Click
    '    Using mForm As New NhapLieuKH(NhapLieuKH.eFormMode.Them, Nothing)
    '        AddHandler mForm.ThemXong, AddressOf FillGrid
    '        mForm.ShowDialog(Me)
    '    End Using

    'End Sub

    'Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
    '    Me.Close()
    'End Sub

    'Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click
    '    Using mForm As New NhapLieuKH(NhapLieuKH.eFormMode.Xem, GridView1.GetFocusedRowCellValue("MaKH"))
    '        mForm.ShowDialog(Me)
    '    End Using
    'End Sub

    'Private Sub btnSua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSua.Click
    '    Using mForm As New NhapLieuKH(NhapLieuKH.eFormMode.Sua, GridView1.GetFocusedRowCellValue("MaKH"))
    '        AddHandler mForm.ThemXong, AddressOf FillGrid
    '        mForm.ShowDialog(Me)
    '    End Using

    'End Sub

    'Private Sub btnXoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoa.Click
    '    Dim db = New DataClasses1DataContext
    '    Dim mData = db.KhachHangs.Where(Function(p) p.MaKH.Equals(GridView1.GetFocusedRowCellValue("MaKH"))).ToList
    '    db.KhachHangs.DeleteAllOnSubmit(mData)
    '    db.SubmitChanges()
    '    FillGrid()
    'End Sub
End Class