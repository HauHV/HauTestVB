﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NhapKhoForm
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.btnXoaThayDoi = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuuDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuu = New DevExpress.XtraEditors.SimpleButton
        Me.txtTenKho = New DevExpress.XtraEditors.TextEdit
        Me.txtMaKho = New DevExpress.XtraEditors.TextEdit
        Me.txtGhiChu = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        Me.txtGhiChu1 = New DevExpress.XtraEditors.TextEdit
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTenKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'btnXoaThayDoi
        '
        Me.btnXoaThayDoi.Location = New System.Drawing.Point(28, 168)
        Me.btnXoaThayDoi.Name = "btnXoaThayDoi"
        Me.btnXoaThayDoi.Size = New System.Drawing.Size(93, 23)
        Me.btnXoaThayDoi.TabIndex = 7
        Me.btnXoaThayDoi.Text = "Xóa thay đổi"
        '
        'btnDong
        '
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Location = New System.Drawing.Point(374, 168)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(63, 23)
        Me.btnDong.TabIndex = 10
        Me.btnDong.Text = "Đóng"
        '
        'btnLuuDong
        '
        Me.btnLuuDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuuDong.Appearance.Options.UseFont = True
        Me.btnLuuDong.Location = New System.Drawing.Point(248, 168)
        Me.btnLuuDong.Name = "btnLuuDong"
        Me.btnLuuDong.Size = New System.Drawing.Size(97, 23)
        Me.btnLuuDong.TabIndex = 9
        Me.btnLuuDong.Text = "Lưu và đóng"
        '
        'btnLuu
        '
        Me.btnLuu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuu.Appearance.Options.UseFont = True
        Me.btnLuu.Location = New System.Drawing.Point(145, 168)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(75, 23)
        Me.btnLuu.TabIndex = 8
        Me.btnLuu.Text = "Lưu"
        '
        'txtTenKho
        '
        Me.txtTenKho.Location = New System.Drawing.Point(101, 80)
        Me.txtTenKho.Name = "txtTenKho"
        Me.txtTenKho.Properties.Mask.EditMask = ".+"
        Me.txtTenKho.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtTenKho.Size = New System.Drawing.Size(336, 20)
        Me.txtTenKho.TabIndex = 2
        '
        'txtMaKho
        '
        Me.txtMaKho.Location = New System.Drawing.Point(101, 45)
        Me.txtMaKho.Name = "txtMaKho"
        Me.txtMaKho.Properties.Mask.EditMask = ".+"
        Me.txtMaKho.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtMaKho.Size = New System.Drawing.Size(336, 20)
        Me.txtMaKho.TabIndex = 1
        '
        'txtGhiChu
        '
        Me.txtGhiChu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Location = New System.Drawing.Point(43, 117)
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Size = New System.Drawing.Size(42, 15)
        Me.txtGhiChu.TabIndex = 5
        Me.txtGhiChu.Text = "Ghi chú"
        '
        'LabelControl2
        '
        Me.LabelControl2.AllowHtmlString = True
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl2.Location = New System.Drawing.Point(28, 82)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl2.TabIndex = 1
        Me.LabelControl2.Text = "Tên Kho <Color=Red><b> *</b></Color>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(36, 47)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(49, 15)
        Me.LabelControl1.TabIndex = 0
        Me.LabelControl1.Text = "Mã Kho<Color=Red><b> *</b></Color>"
        '
        'txtGhiChu1
        '
        Me.txtGhiChu1.Location = New System.Drawing.Point(101, 115)
        Me.txtGhiChu1.Name = "txtGhiChu1"
        Me.txtGhiChu1.Size = New System.Drawing.Size(336, 20)
        Me.txtGhiChu1.TabIndex = 6
        '
        'NhapKhoForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(461, 215)
        Me.Controls.Add(Me.txtGhiChu1)
        Me.Controls.Add(Me.btnXoaThayDoi)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.btnLuuDong)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.txtTenKho)
        Me.Controls.Add(Me.txtMaKho)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.LabelControl2)
        Me.Controls.Add(Me.LabelControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "NhapKhoForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Thêm hàng hóa mới"
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTenKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents btnXoaThayDoi As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuuDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents txtTenKho As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtMaKho As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtGhiChu As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtGhiChu1 As DevExpress.XtraEditors.TextEdit
End Class
