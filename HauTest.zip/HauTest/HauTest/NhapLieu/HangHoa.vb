﻿Public Class HangHoa
    
    Private Sub HangHoa_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FillGrid()
    End Sub

    Private Sub FillGrid()
        Dim db As New DataClasses1DataContext
        GridHang.DataSource = db.HangHoas.ToList()
    End Sub

    Private Sub btnThem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThem.Click
        Using mForm As New NhapLieuHangHoa(NhapLieuHangHoa.eFormMode.Them, Nothing)
            AddHandler mForm.ThemXong, AddressOf FillGrid
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click
        Using mForm As New NhapLieuHangHoa(NhapLieuHangHoa.eFormMode.Xem, GridView1.GetFocusedRowCellValue("MaHang"))
            mForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub btnSua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSua.Click
        Using mForm As New NhapLieuHangHoa(NhapLieuHangHoa.eFormMode.Sua, GridView1.GetFocusedRowCellValue("MaHang"))
            AddHandler mForm.ThemXong, AddressOf FillGrid
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnXoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoa.Click
        Dim db = New DataClasses1DataContext
        Dim mData = db.HangHoas.Where(Function(p) p.MaHang.Equals(GridView1.GetFocusedRowCellValue("MaHang"))).ToList
        db.HangHoas.DeleteAllOnSubmit(mData)
        db.SubmitChanges()
        FillGrid()
    End Sub
End Class