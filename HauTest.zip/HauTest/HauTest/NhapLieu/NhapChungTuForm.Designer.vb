﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NhapChungTuForm
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.btnXoaThayDoi = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuuDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuu = New DevExpress.XtraEditors.SimpleButton
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'btnXoaThayDoi
        '
        Me.btnXoaThayDoi.Location = New System.Drawing.Point(182, 340)
        Me.btnXoaThayDoi.Name = "btnXoaThayDoi"
        Me.btnXoaThayDoi.Size = New System.Drawing.Size(97, 23)
        Me.btnXoaThayDoi.TabIndex = 7
        Me.btnXoaThayDoi.Text = "Xóa thay đổi"
        '
        'btnDong
        '
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Location = New System.Drawing.Point(532, 340)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(63, 23)
        Me.btnDong.TabIndex = 10
        Me.btnDong.Text = "Đóng"
        '
        'btnLuuDong
        '
        Me.btnLuuDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuuDong.Appearance.Options.UseFont = True
        Me.btnLuuDong.Location = New System.Drawing.Point(406, 340)
        Me.btnLuuDong.Name = "btnLuuDong"
        Me.btnLuuDong.Size = New System.Drawing.Size(97, 23)
        Me.btnLuuDong.TabIndex = 9
        Me.btnLuuDong.Text = "Lưu và đóng"
        '
        'btnLuu
        '
        Me.btnLuu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuu.Appearance.Options.UseFont = True
        Me.btnLuu.Location = New System.Drawing.Point(303, 340)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(75, 23)
        Me.btnLuu.TabIndex = 8
        Me.btnLuu.Text = "Lưu"
        '
        'GridControl1
        '
        Me.GridControl1.Location = New System.Drawing.Point(1, 2)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(733, 314)
        Me.GridControl1.TabIndex = 11
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'NhapChungTuForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(735, 405)
        Me.Controls.Add(Me.GridControl1)
        Me.Controls.Add(Me.btnXoaThayDoi)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.btnLuuDong)
        Me.Controls.Add(Me.btnLuu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "NhapChungTuForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Thêm chứng từ mới"
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents btnXoaThayDoi As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuuDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
End Class
