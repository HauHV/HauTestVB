﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class NhapKhachHang

    Private Sub NhapKhachHang_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReadIniFile()
        ConnectDB()
        RefreshData()
    End Sub

    Private Sub RefreshData()
        Dim db As New DataClasses1DataContext(ConnectionString)
        Dim KH = db.KhachHangs.ToList
        GridHang.DataSource = KH
    End Sub
    Private Sub btnThem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThem.Click
        Using mForm As New NhapKHForm(NhapKHForm.eFormMode.Them, Nothing)
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click
        Using mForm As New NhapKHForm(NhapKHForm.eFormMode.Xem, GridView1.GetFocusedRowCellValue("MaKH"))
            mForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub btnSua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSua.Click
        Using mForm As New NhapKHForm(NhapKHForm.eFormMode.Sua, GridView1.GetFocusedRowCellValue("MaKH"))
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnXoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoa.Click
        Dim db = New DataClasses1DataContext
        Dim mData = db.KhachHangs.Where(Function(p) p.MaKH.Equals(GridView1.GetFocusedRowCellValue("MaKH"))).ToList
        MsgBox("WTF, Are you OK?")
        If mData.Count() = 0 Then
            MsgBox("Are you OK? Nothing to DELETE!")
        Else
            db.KhachHangs.DeleteAllOnSubmit(mData)
            db.SubmitChanges()
            RefreshData()
        End If
        
    End Sub
   
End Class