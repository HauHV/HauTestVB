﻿Public Class NhapKhoForm
    'Khai báo DataContext
    Dim db As New DataClasses1DataContext

    Private _MaKho As String
    Private FormMode As eFormMode
    Public Enum eFormMode
        None = 0
        Them = 1
        Xem = 2
        Sua = 3
    End Enum

    Public Event ThemXong()

    Public Sub New()
        InitializeComponent()
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pMaKho As String)
        InitializeComponent()
        FormMode = pFormMode
        _MaKho = pMaKho
    End Sub
    'Tạo DX form
    Private Sub ThemForm_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub

    'Hàm thêm hàng hóa
    Private Sub ThemFunction()

        If txtMaKho.EditValue = "" Or txtTenKho.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaKho, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenKho, "Dữ liệu không được trống")
        Else
            Dim anew = New Kho
            anew.MaKho = txtMaKho.EditValue
            anew.TenKho = txtTenKho.EditValue
            anew.GhiChu = txtGhiChu1.EditValue

            db.Khos.InsertOnSubmit(anew)
            db.SubmitChanges()

            RaiseEvent ThemXong()
        End If

    End Sub

    Private Sub RefreshThemForm()
        txtMaKho.EditValue = Nothing
        txtTenKho.EditValue = Nothing
        txtGhiChu1.EditValue = Nothing
    End Sub

    Private Sub SuaFunction()
        If txtMaKho.EditValue = "" Or txtTenKho.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaKho, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenKho, "Dữ liệu không được trống")
        Else
            Dim db = New DataClasses1DataContext
            Dim mData = db.Khos.FirstOrDefault(Function(p) p.MaKho.Equals(_MaKho))
            With mData
                mData.MaKho = txtMaKho.EditValue
                mData.TenKho = txtTenKho.EditValue
                mData.GhiChu = txtGhiChu1.EditValue
            End With

            db.SubmitChanges()
            RaiseEvent ThemXong()
        End If
    End Sub

    Private Sub btnLuu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuu.Click

        ThemFunction()
        RefreshThemForm()
    End Sub

    Private Sub btnLuuDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuuDong.Click
        Select Case FormMode
            Case eFormMode.Them
                ThemFunction()
                Me.Close()
            Case eFormMode.Sua
                SuaFunction()
                Me.Close()
        End Select

    End Sub

    Private Sub btnXoaThayDoi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoaThayDoi.Click
        RefreshThemForm()
    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub ThemForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Select Case FormMode
            Case eFormMode.Them
                ' nothing
            Case eFormMode.Sua
                Dim db = New DataClasses1DataContext
                Dim mData = db.Khos.FirstOrDefault(Function(p) p.MaKho.Equals(_MaKho))
                With mData
                    txtMaKho.EditValue = mData.MaKho
                    txtTenKho.EditValue = mData.TenKho
                    txtGhiChu1.EditValue = mData.GhiChu
                End With
                btnLuu.Visible = False
                'btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
            Case eFormMode.Xem
                Dim db = New DataClasses1DataContext
                Dim mData = db.Khos.FirstOrDefault(Function(p) p.MaKho.Equals(_MaKho))
                With mData
                    txtMaKho.EditValue = mData.MaKho
                    txtTenKho.EditValue = mData.TenKho
                    txtGhiChu1.EditValue = mData.GhiChu
                End With
                btnLuu.Visible = False
                btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
        End Select
    End Sub

End Class