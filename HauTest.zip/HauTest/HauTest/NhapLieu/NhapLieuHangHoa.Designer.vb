﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NhapLieuHangHoa
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.txtDVT = New DevExpress.XtraEditors.TextEdit
        Me.btnXoaThayDoi = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuuDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuu = New DevExpress.XtraEditors.SimpleButton
        Me.txtMax = New DevExpress.XtraEditors.TextEdit
        Me.txtTenHang = New DevExpress.XtraEditors.TextEdit
        Me.txtMaHang = New DevExpress.XtraEditors.TextEdit
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        Me.txtMin = New DevExpress.XtraEditors.TextEdit
        Me.txtGhiChu = New DevExpress.XtraEditors.TextEdit
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDVT.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMax.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMin.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'txtDVT
        '
        Me.txtDVT.Location = New System.Drawing.Point(110, 103)
        Me.txtDVT.Name = "txtDVT"
        Me.txtDVT.Size = New System.Drawing.Size(109, 20)
        Me.txtDVT.TabIndex = 3
        '
        'btnXoaThayDoi
        '
        Me.btnXoaThayDoi.Location = New System.Drawing.Point(23, 254)
        Me.btnXoaThayDoi.Name = "btnXoaThayDoi"
        Me.btnXoaThayDoi.Size = New System.Drawing.Size(97, 23)
        Me.btnXoaThayDoi.TabIndex = 7
        Me.btnXoaThayDoi.Text = "Xóa thay đổi"
        '
        'btnDong
        '
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Location = New System.Drawing.Point(373, 254)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(63, 23)
        Me.btnDong.TabIndex = 10
        Me.btnDong.Text = "Đóng"
        '
        'btnLuuDong
        '
        Me.btnLuuDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuuDong.Appearance.Options.UseFont = True
        Me.btnLuuDong.Location = New System.Drawing.Point(247, 254)
        Me.btnLuuDong.Name = "btnLuuDong"
        Me.btnLuuDong.Size = New System.Drawing.Size(97, 23)
        Me.btnLuuDong.TabIndex = 9
        Me.btnLuuDong.Text = "Lưu và đóng"
        '
        'btnLuu
        '
        Me.btnLuu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuu.Appearance.Options.UseFont = True
        Me.btnLuu.Location = New System.Drawing.Point(144, 254)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(75, 23)
        Me.btnLuu.TabIndex = 8
        Me.btnLuu.Text = "Lưu"
        '
        'txtMax
        '
        Me.txtMax.Location = New System.Drawing.Point(110, 164)
        Me.txtMax.Name = "txtMax"
        Me.txtMax.Properties.Mask.EditMask = "N1"
        Me.txtMax.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtMax.Size = New System.Drawing.Size(265, 20)
        Me.txtMax.TabIndex = 5
        '
        'txtTenHang
        '
        Me.txtTenHang.Location = New System.Drawing.Point(110, 77)
        Me.txtTenHang.Name = "txtTenHang"
        Me.txtTenHang.Properties.Mask.EditMask = ".+"
        Me.txtTenHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtTenHang.Size = New System.Drawing.Size(265, 20)
        Me.txtTenHang.TabIndex = 2
        '
        'txtMaHang
        '
        Me.txtMaHang.Location = New System.Drawing.Point(110, 50)
        Me.txtMaHang.Name = "txtMaHang"
        Me.txtMaHang.Properties.Mask.EditMask = ".+"
        Me.txtMaHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtMaHang.Size = New System.Drawing.Size(265, 20)
        Me.txtMaHang.TabIndex = 1
        '
        'LabelControl6
        '
        Me.LabelControl6.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl6.Location = New System.Drawing.Point(44, 195)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(42, 15)
        Me.LabelControl6.TabIndex = 5
        Me.LabelControl6.Text = "GhiChu"
        '
        'LabelControl5
        '
        Me.LabelControl5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl5.Location = New System.Drawing.Point(12, 166)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(92, 15)
        Me.LabelControl5.TabIndex = 4
        Me.LabelControl5.Text = "SoLuongTonMax"
        '
        'LabelControl4
        '
        Me.LabelControl4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl4.Location = New System.Drawing.Point(14, 137)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(90, 15)
        Me.LabelControl4.TabIndex = 3
        Me.LabelControl4.Text = "SoLuongTonMin"
        '
        'LabelControl3
        '
        Me.LabelControl3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl3.Location = New System.Drawing.Point(44, 108)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(23, 15)
        Me.LabelControl3.TabIndex = 2
        Me.LabelControl3.Text = "DVT"
        '
        'LabelControl2
        '
        Me.LabelControl2.AllowHtmlString = True
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl2.Location = New System.Drawing.Point(39, 80)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(65, 15)
        Me.LabelControl2.TabIndex = 1
        Me.LabelControl2.Text = "Tên Hang <Color=Red><b> *</b></Color>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(47, 52)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl1.TabIndex = 0
        Me.LabelControl1.Text = "Mã Hang<Color=Red><b> *</b></Color>"
        '
        'txtMin
        '
        Me.txtMin.Location = New System.Drawing.Point(110, 135)
        Me.txtMin.Name = "txtMin"
        Me.txtMin.Properties.Mask.EditMask = "n1"
        Me.txtMin.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtMin.Size = New System.Drawing.Size(265, 20)
        Me.txtMin.TabIndex = 4
        '
        'txtGhiChu
        '
        Me.txtGhiChu.Location = New System.Drawing.Point(112, 193)
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Properties.Mask.EditMask = "N2"
        Me.txtGhiChu.Size = New System.Drawing.Size(263, 20)
        Me.txtGhiChu.TabIndex = 6
        '
        'NhapLieuKH
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 323)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.txtMin)
        Me.Controls.Add(Me.txtDVT)
        Me.Controls.Add(Me.btnXoaThayDoi)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.btnLuuDong)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.txtMax)
        Me.Controls.Add(Me.txtTenHang)
        Me.Controls.Add(Me.txtMaHang)
        Me.Controls.Add(Me.LabelControl6)
        Me.Controls.Add(Me.LabelControl5)
        Me.Controls.Add(Me.LabelControl4)
        Me.Controls.Add(Me.LabelControl3)
        Me.Controls.Add(Me.LabelControl2)
        Me.Controls.Add(Me.LabelControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "NhapLieuKH"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Thêm hàng hóa mới"
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDVT.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMax.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMin.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents txtMin As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtDVT As DevExpress.XtraEditors.TextEdit
    Friend WithEvents btnXoaThayDoi As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuuDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents txtMax As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtTenHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtMaHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtGhiChu As DevExpress.XtraEditors.TextEdit
End Class
