﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HangHoa
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SimpleButton11 = New DevExpress.XtraEditors.SimpleButton
        Me.btnXem = New DevExpress.XtraEditors.SimpleButton
        Me.btnThem = New DevExpress.XtraEditors.SimpleButton
        Me.btnXoa = New DevExpress.XtraEditors.SimpleButton
        Me.btnSua = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.GridHang = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        CType(Me.GridHang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SimpleButton11
        '
        Me.SimpleButton11.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton11.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton11.Appearance.Options.UseFont = True
        Me.SimpleButton11.Image = Global.HauTest.My.Resources.Resources.CMD_EXCEL01
        Me.SimpleButton11.Location = New System.Drawing.Point(240, 390)
        Me.SimpleButton11.Name = "SimpleButton11"
        Me.SimpleButton11.Size = New System.Drawing.Size(29, 23)
        Me.SimpleButton11.TabIndex = 54
        '
        'btnXem
        '
        Me.btnXem.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXem.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnXem.Appearance.Options.UseFont = True
        Me.btnXem.Image = Global.HauTest.My.Resources.Resources.iItemList09_16
        Me.btnXem.Location = New System.Drawing.Point(285, 390)
        Me.btnXem.Name = "btnXem"
        Me.btnXem.Size = New System.Drawing.Size(80, 23)
        Me.btnXem.TabIndex = 53
        Me.btnXem.Text = "Xem"
        '
        'btnThem
        '
        Me.btnThem.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnThem.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnThem.Appearance.Options.UseFont = True
        Me.btnThem.Image = Global.HauTest.My.Resources.Resources.CMD_ADD01
        Me.btnThem.Location = New System.Drawing.Point(381, 390)
        Me.btnThem.Name = "btnThem"
        Me.btnThem.Size = New System.Drawing.Size(80, 23)
        Me.btnThem.TabIndex = 52
        Me.btnThem.Text = "Thêm"
        '
        'btnXoa
        '
        Me.btnXoa.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXoa.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnXoa.Appearance.Options.UseFont = True
        Me.btnXoa.Image = Global.HauTest.My.Resources.Resources.CMD_DELETE01
        Me.btnXoa.Location = New System.Drawing.Point(477, 390)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(80, 23)
        Me.btnXoa.TabIndex = 51
        Me.btnXoa.Text = "Xóa"
        '
        'btnSua
        '
        Me.btnSua.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSua.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnSua.Appearance.Options.UseFont = True
        Me.btnSua.Image = Global.HauTest.My.Resources.Resources.CMD_EDIT01
        Me.btnSua.Location = New System.Drawing.Point(573, 390)
        Me.btnSua.Name = "btnSua"
        Me.btnSua.Size = New System.Drawing.Size(80, 23)
        Me.btnSua.TabIndex = 50
        Me.btnSua.Text = "Sửa"
        '
        'btnDong
        '
        Me.btnDong.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Image = Global.HauTest.My.Resources.Resources.CMD_EXIT01
        Me.btnDong.Location = New System.Drawing.Point(669, 390)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(80, 23)
        Me.btnDong.TabIndex = 49
        Me.btnDong.Text = "Đóng"
        '
        'GridHang
        '
        Me.GridHang.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridHang.Location = New System.Drawing.Point(0, 1)
        Me.GridHang.MainView = Me.GridView1
        Me.GridHang.Name = "GridHang"
        Me.GridHang.Size = New System.Drawing.Size(763, 373)
        Me.GridHang.TabIndex = 48
        Me.GridHang.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Appearance.FocusedRow.Options.UseTextOptions = True
        Me.GridView1.Appearance.FocusedRow.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GridView1.Appearance.OddRow.Options.UseBackColor = True
        Me.GridView1.Appearance.Row.Options.UseTextOptions = True
        Me.GridView1.Appearance.Row.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.GridControl = Me.GridHang
        Me.GridView1.Name = "GridView1"
        '
        'HangHoa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(763, 425)
        Me.Controls.Add(Me.SimpleButton11)
        Me.Controls.Add(Me.btnXem)
        Me.Controls.Add(Me.btnThem)
        Me.Controls.Add(Me.btnXoa)
        Me.Controls.Add(Me.btnSua)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.GridHang)
        Me.Name = "HangHoa"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "N_HangHoa"
        CType(Me.GridHang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SimpleButton11 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnXem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnThem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnXoa As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnSua As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents GridHang As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
End Class
