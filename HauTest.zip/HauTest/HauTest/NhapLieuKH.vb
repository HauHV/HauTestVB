﻿Public Class NhapLieuKH
    'Khai báo DataContext
    Dim db As New DataClasses1DataContext

    Private _MaKH As String
    Private FormMode As eFormMode
    Public Enum eFormMode
        None = 0
        Them = 1
        Xem = 2
        Sua = 3
    End Enum

    Public Event ThemXong()

    'Public Sub New()
    '    InitializeComponent()
    'End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pMaKH As String)
        InitializeComponent()
        FormMode = pFormMode
        _MaKH = pMaKH
    End Sub
    'Tạo DX form
    Private Sub ThemForm_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub

    'Hàm thêm hàng hóa
    Private Sub ThemFunction()

        If txtMaKH.EditValue = "" Or txtTenKH.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaKH, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenKH, "Dữ liệu không được trống")
        Else
            Dim anew = New KhachHang
            anew.MaKH = txtMaKH.EditValue
            anew.TenKH = txtTenKH.EditValue
            anew.DiaChi = txtDiaChi.EditValue
            anew.SDT = txtSDT.EditValue
            anew.GhiChu = txtGhiChu.EditValue

            db.KhachHangs.InsertOnSubmit(anew)
            db.SubmitChanges()

            RaiseEvent ThemXong()
        End If

    End Sub

    Private Sub RefreshThemForm()
        txtMaKH.EditValue = Nothing
        txtTenKH.EditValue = Nothing
        txtDiaChi.EditValue = 0.0
        txtSDT.EditValue = 0.0

    End Sub

    Private Sub SuaFunction()
        If txtMaKH.EditValue = "" Or txtTenKH.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaKH, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenKH, "Dữ liệu không được trống")
        Else
            Dim db = New DataClasses1DataContext
            Dim mData = db.KhachHangs.FirstOrDefault(Function(p) p.MaKH.Equals(_MaKH))
            With mData

                mData.MaKH = txtMaKH.EditValue
                mData.TenKH = txtTenKH.EditValue
                mData.DiaChi = txtDiaChi.EditValue
                mData.SDT = txtSDT.EditValue
                mData.GhiChu = txtGhiChu.EditValue
            End With

            db.SubmitChanges()
            RaiseEvent ThemXong()
        End If
    End Sub

    Private Sub btnLuu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuu.Click

        ThemFunction()
        RefreshThemForm()
    End Sub

    Private Sub btnLuuDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuuDong.Click
        Select Case FormMode
            Case eFormMode.Them
                ThemFunction()
                Me.Close()
            Case eFormMode.Sua
                SuaFunction()
                Me.Close()
        End Select

    End Sub

    Private Sub btnXoaThayDoi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoaThayDoi.Click
        RefreshThemForm()
    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub ThemForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Select Case FormMode
            Case eFormMode.Them
                ' nothing
            Case eFormMode.Sua
                Dim db = New DataClasses1DataContext
                Dim mData = db.KhachHangs.FirstOrDefault(Function(p) p.MaKH.Equals(_MaKH))
                With mData
                    txtMaKH.EditValue = mData.MaKH
                    txtTenKH.EditValue = mData.TenKH
                    txtDiaChi.EditValue = mData.DiaChi
                    txtSDT.EditValue = mData.SDT
                    txtGhiChu.EditValue = mData.GhiChu
                End With
                btnLuu.Visible = False
                'btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
            Case eFormMode.Xem
                Dim db = New DataClasses1DataContext
                Dim mData = db.KhachHangs.FirstOrDefault(Function(p) p.MaKH.Equals(_MaKH))
                With mData
                    txtMaKH.EditValue = mData.MaKH
                    txtTenKH.EditValue = mData.TenKH
                    txtDiaChi.EditValue = mData.DiaChi
                    txtSDT.EditValue = mData.SDT
                    txtGhiChu.EditValue = mData.GhiChu
                End With
                btnLuu.Visible = False
                btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
        End Select
    End Sub

End Class